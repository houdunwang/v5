<?php
define('DEBUG',1);
define('APP_PATH','index/');
require '../hdphp/hdphp/hdphp.php';