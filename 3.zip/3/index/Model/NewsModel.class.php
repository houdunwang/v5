<?php
class NewsModel extends Model{
	//模型操作的表
	public $table='news';
	public function abc(){
		echo 'houdunwang.com';
	}
}