<?php if(!defined("HDPHP_PATH"))exit;C("SHOW_NOTICE",FALSE);?><h1><?php echo $field['title'];?></h1>
<p>
<?php echo $field['content'];?>
	</p>