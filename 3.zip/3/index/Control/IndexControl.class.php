<?php
//测试控制器类
class IndexControl extends Control{
    function index(){
    
    }
}
?>