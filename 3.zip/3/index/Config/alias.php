<?php
if (!defined("HDPHP_PATH")) exit('No direct script access allowed');

/**
 * 别名导入配置项
 * 类文件系统会自动导入，其他文件使用alias_import函数导入
*/
return array(

);
?>
